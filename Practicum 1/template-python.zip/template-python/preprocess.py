import re
import sqlite3
import os


class WorkloadNumericalItem:
    """
    A single workload numerical item

    count is how often this occurred
    attribute is the attribute (column) that is queried
    value is the value that is queried
    """

    def __init__(self, count: int, attribute: str, value: float):
        self.count = count
        self.attribute = attribute
        self.value = value

    def __repr__(self):
        return "WorkloadNumericalItem('{} times: {} = {}')".format(
            self.count, self.attribute, self.value)


class WorkloadCategoricalItem:
    """
    A single workload categorical item

    count is how often this occurred
    attribute is the attribute (column) that is queried
    value is the value that is queried
    """

    def __init__(self, count: int, attribute: str, value: str):
        self.count = count
        self.attribute = attribute
        self.value = value

    def __repr__(self):
        return "WorkloadCategoricalItem('{} times: {} = {}')".format(
            self.count, self.attribute, self.value)


class WorkloadList:
    """
    A wokload item that occurs together with other items

    count is how often this occurred
    attribute is the attribute (column) that is queried
    values is the list of associated values
    """

    def __init__(self, count: int, attribute: str, values: list[str]):
        self.count = count
        self.attribute = attribute
        self.values = values

    def __repr__(self):
        return "WorkloadList('{} times: {} IN {}')".format(
            self.count, self.attribute, self.values)


def read_workload() -> tuple[list[WorkloadCategoricalItem],
                             list[WorkloadNumericalItem], list[WorkloadList]]:
    """
    Read in the query workload
    
    Returns both the workload items found, 
    both categorical and numerical (column = value), 
    and the workload lists found (column IN (...))
    """
    with open('resources/workload.txt') as f:
        workload = f.read()

    items_cat = []
    items_num = []
    lists = []

    # capture 'number times: ...'
    capture_count = re.compile(r'(\d+) times: SELECT .* FROM .* WHERE (.*)')

    # capture 'key = 'value-seperated''
    capture_cat = re.compile(r'(\S*)\s*=\s*\'([a-zA-Z-]*)\'')

    # capture 'key = 123.456'
    capture_num = re.compile(r'(\S*)\s*=\s*\'([\d\.]*)\'')

    # capture 'key IN ('a', 'b')'
    capture_in = re.compile(r'(\S*)\s*IN\s*\((.*)\)')

    # capture 'string'
    capture_str = re.compile(r'\'([\w -]*)\'')

    for count, query in capture_count.findall(workload):
        count_num = int(count)

        # find all the ... IN ...
        for key, values in capture_in.findall(query):
            separated_values: list[str] = capture_str.findall(values)
            lists.append(WorkloadList(count_num, key, separated_values))

        # find all the key = 123.456
        for key, value in capture_num.findall(query):
            if key in categorical_atts:
                items_cat.append(WorkloadCategoricalItem(count_num, key, value))
            else:
                items_num.append(WorkloadNumericalItem(count_num, key, float(value)))

        # find all the key = 'value'
        for key, value in capture_cat.findall(query):
            items_cat.append(WorkloadCategoricalItem(count_num, key, value))

    return (items_cat, items_num, lists)


class NumericalEntry:
    """
    An numerical entry in the database
    
    attribute is the column it's from
    value is it's numerical value
    id is the row this item is from
    """

    def __init__(self, id: int, attribute: str, value: float):
        self.id = id
        self.attribute = attribute
        self.value = value

    def __repr__(self):
        return "NumericalEntry('{}: {} = {}')".format(self.id, self.attribute,
                                                      self.value)


class CategoricalEntry:
    """ 
    A categorical entry in the database

    attribute is the column it's from
    value is it's categorical value, as a string
    id is the row this item was from
    """

    def __init__(self, id: int, attribute: str, value: str):
        self.id = id
        self.attribute = attribute
        self.value = value

    def __repr__(self):
        return "CategoricalEntry('{}: {} = {}')".format(
            self.id, self.attribute, self.value)


def read_and_create_database(
) -> tuple[list[CategoricalEntry], list[NumericalEntry]]:
    """
    Reads the database from the file that fills it, 
    and creates a new sqlite database

    returns both the numerical and categorical entries in the database
    """
    # clear the database, if it exists
    try:
        os.remove("resources/autompg.sqlite")
    except:
        pass

    # load in the database
    with open("resources/autompg.sql") as f:
        sql = f.read()
        con = sqlite3.connect("resources/autompg.sqlite")
        con.executescript(sql)

    # read all the entries from the table
    cur = con.execute("SELECT * FROM autompg")
    cur.row_factory = sqlite3.Row  # type: ignore
    categorical = []
    numerical = []

    for row in cur:
        id = row[0]
        keys = row.keys()
        without_id = row[1:]
        keys_without_id = keys[1:]
        for value, col in zip(without_id, keys_without_id):
            if col in numerical_atts:
                numerical.append(NumericalEntry(id, col, float(value)))
            else:
                categorical.append(CategoricalEntry(id, col, value))


    return (categorical, numerical)


class MetaDB:
    """
    Represents the MetaDatabase, with functionality to fill the database
    Automatically creates metadb.txt and metaload.txt
    """

    def __init__(self):
        self.metadb = ""
        self.metaload = ""

    def add_table(self, name: str, types: list[tuple[str, str]],
                  values: list[list]):
        """
        Adds a new table to the database

        name is the column name
        types is a list of name, type tuples for each column in the table
        and values is a list of lists of the values to insert

        this runs the following as SQL:
        ```
        CREATE TABLE name (
            types[0][0] types[0][1],
            types[1][0] types[1][1],
            ...
        );
        ```

        and to fill the table:
        ```
        -- name
        INSERT INTO name VALUES (values[0][0], values[0][1], values[0][2], ...);
        INSERT INTO name VALUES (values[1][0], values[1][1], values[1][2], ...);
        INSERT INTO name VALUES ...;
        ```

        For strings, the needed "" are added automatically

        To see the full output, run this file, 
        then look at metadb.txt and metaload.txt
        """

        # don't do this when actually executing SQL queries
        self.metadb += "CREATE TABLE " + name + " (\n"

        for idx, (colname, coltype) in enumerate(types):
            self.metadb += "    " + colname + " " + coltype + (
                ",\n" if idx < len(types) - 1 else "\n")

        self.metadb += ");\n\n"

        # fill the table
        self.metaload += "-- " + name + "\n"
        for row in values:
            self.metaload += "INSERT INTO " + name + " VALUES ("
            for idx, value in enumerate(row):
                self.metaload += '"' + value + '"' if isinstance(
                    value, str) else str(value)
                self.metaload += ", " if idx < len(row) - 1 else ""
            self.metaload += ");\n"

    def create(self):
        """
        Creates the database as an sqlite database named metadb.sqlite
        as well as metadb.txt and metaload.txt
        """

        # clear existing database, if any
        try:
            os.remove("resources/metadb.sqlite")
        except:
            pass

        # write the files
        with open("resources/metadb.txt", "w") as f:
            f.write(self.metadb)
        with open("resources/metaload.txt", "w") as f:
            f.write(self.metaload)

        # fill the db
        con = sqlite3.connect("resources/metadb.sqlite")
        con.executescript(self.metadb)
        con.executescript(self.metaload)


def preprocess():
    """
    Preprocess all data, and create the metadb
    """

    # TODO: implement this!
    # The template only provides an example that adds the counts of the categorical entries to the MetaDB
    workload_categorical, workload_numerical, workload_lists = read_workload()
    database_categorical, database_numerical = read_and_create_database()

    # count all categorical entries
    counts = {}
    for entry in workload_categorical:
        key = (entry.attribute, entry.value)
        count = counts[key] if key in counts else 0
        counts[key] = count + entry.count

    # create a metadb
    db = MetaDB()

    # add the counts table
    db.add_table('counts_categorical', [("attribute", "TEXT"),
                                        ("value", "TEXT"), ("count", "real")],
                 [[key[0], key[1], value] for key, value in counts.items()])

    # create the database, metadb.txt and metaload.txt
    db.create()

# TODO: inspect the database, and choose for yourself which attributes should be considered
# numerical and which ones should be considered categorical
# place the names of those attributes in these lists,
# such that the values in the database are properly classified according to your choices
categorical_atts: list[str] = []
numerical_atts: list[str] = []

if __name__ == "__main__":
    preprocess()
