import re
import sqlite3

# Import readline, which makes navigation the CEQ with arrow keys possible
try:
    import readline
except:
    pass


class CeqEntry:
    """
    Single entry in the CEQ

    attribute is the attribute to query
    value is the value of that attribute
    """

    def __init__(self, attribute: str, value: str | float):
        self.attribute = attribute
        self.value = value


def parse_ceq(ceq: str) -> tuple[int, list[CeqEntry]]:
    """
    Parse a CEQ, and return the found k and the list of entries
    """

    # default to 10
    k = 10
    entries = []

    # capture 'alphanum = 1234
    capture_num = re.compile(r'(\w+)\s*=\s*(\d+)')

    # capture 'alphanum = "alphanum-and-dash"'
    capture_cat = re.compile(r'(\w+)\s*=\s*\'([a-zA-Z-]+)\'')

    # find all matches, then add it to the entry
    for key, value in capture_num.findall(ceq):
        if key == "k":
            # k is not part of what we want to search, but it instead determines how much we want to search
            k = int(value)
        else:
            entries.append(CeqEntry(key, float(value)))

    for key, value in capture_cat.findall(ceq):
        entries.append(CeqEntry(key, value))

    return (k, entries)


def pretty_print_results(head: list[str], scores: list[float],
                         rows: list[tuple]):
    """
    Pretty prints the results

    Head are the column names, rows is a list of tuples for each row
    Scores is the list of scores for each row, to tell how it ranked
    It won't be sorted here
    """
    # attatch the score to the head
    head = ["K", "Score", *head]

    # attatch the score to the rows
    rows_with_score = [[str(i + 1), "{:.4f}".format(score), *row]
                       for i, (score, row) in enumerate(zip(scores, rows))]

    # figure out the text widths for pretty printing
    text_widths = [len(str(x)) for x in head]
    for row in rows_with_score:
        for i, col in enumerate(row):
            text_widths[i] = max(text_widths[i], len(str(col)))

    # print head
    print(" │ ".join([x.rjust(l, ' ') for x, l in zip(head, text_widths)]))

    # divider
    print("─┼─".join(['─' * l for l in text_widths]))

    # rows
    for row in rows_with_score:
        print(" │ ".join(
            [str(x).rjust(l, ' ') for x, l in zip(row, text_widths)]))


def query(k: int, attributes: list[CeqEntry]):
    """ 
    Run a query, and print the result
    """

    # TODO: implement this!
    # the template only provides an example that returns full matches
    
    # In reality, don't do this, as it's prone to SQL injections!
    query = "SELECT * FROM autompg WHERE " + " AND ".join(
        ['{} = "{}"'.format(x.attribute, x.value) for x in attributes])

    # get the results
    con = sqlite3.connect("resources/autompg.sqlite")
    cur = con.execute(query)

    # get K results
    results = cur.fetchmany(k)

    # pretty print the results and their scores
    # scores is simply 1, because there's no ranking yet
    pretty_print_results([x[0] for x in cur.description],
                         [1.0 for _ in range(k)], results)


if __name__ == "__main__":
    # ask for a ceq forever
    print("Enter a CEQ, or :q to exit")
    while True:
        ceq = input('> ')
        if ceq == ":q":
            break

        k, entries = parse_ceq(ceq)
        if (len(entries) == 0): 
            print("I couldn't parse that, check your input")
        else: 
            query(k, entries)
